package com.udacity.catpoint.security.data;

public enum SecuritySensorType {
    DOOR, WINDOW, MOTION
}
