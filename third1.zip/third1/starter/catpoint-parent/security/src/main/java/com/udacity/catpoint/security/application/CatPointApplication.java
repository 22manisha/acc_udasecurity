package com.udacity.catpoint.security.application;

public class CatPointApplication {
    public static void main(String[] args) {
        CatPointGUI gui = new CatPointGUI();
        gui.setVisible(true);
    }
}
