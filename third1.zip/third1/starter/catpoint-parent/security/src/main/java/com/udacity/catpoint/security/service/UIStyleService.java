package com.udacity.catpoint.security.service;

import java.awt.*;
public class UIStyleService {

    public static final Font HEADING_FONT = new Font("Sans Serif", Font.BOLD, 24);

}
